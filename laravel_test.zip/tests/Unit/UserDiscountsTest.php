<?php

namespace Tests\Unit;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use UserDiscounts\Models\Discount;
use UserDiscounts\Models\UserDiscount;
use UserDiscounts\Services\DiscountManager;
use Tests\TestCase;

class UserDiscountsTest extends TestCase
{
    use RefreshDatabase;

    public function test_stacking_and_usage_cap_are_enforced(): void
    {
        $user = User::factory()->create();

        // Two discounts: 10% then fixed 5, with a per-user cap of 1 on the fixed discount.
        $percentage = Discount::create([
            'code' => 'P10',
            'name' => '10 percent off',
            'type' => 'percentage',
            'value' => 10,
            'active' => true,
        ]);

        $fixed = Discount::create([
            'code' => 'F5',
            'name' => '5 off',
            'type' => 'fixed',
            'value' => 5,
            'active' => true,
        ]);

        /** @var DiscountManager $manager */
        $manager = $this->app->make(DiscountManager::class);

        $manager->assign($user->id, $percentage->id, maxUses: null);
        $manager->assign($user->id, $fixed->id, maxUses: 1);

        $result1 = $manager->apply($user->id, 100.00, reference: 'order-1');

        // Stacking order default: percentage then fixed.
        // 100 - 10% = 90, then -5 = 85, rounded half_up.
        $this->assertSame(100.00, $result1['original']);
        $this->assertSame(85.00, $result1['final']);
        $this->assertCount(2, $result1['applied_discounts']);

        // Second application: fixed discount should have hit its cap and no longer apply.
        $result2 = $manager->apply($user->id, 100.00, reference: 'order-2');

        // Only the percentage discount should apply now: 100 - 10% = 90.
        $this->assertSame(90.00, $result2['final']);
        $this->assertCount(1, $result2['applied_discounts']);

        $this->assertDatabaseHas('user_discounts', [
            'user_id' => $user->id,
            'discount_id' => $fixed->id,
            'used' => 1,
        ]);
    }
}




