<?php

namespace Tests\Unit;

use App\Models\Product;
use App\Services\ProductCsvImporter;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ProductCsvImporterTest extends TestCase
{
    use RefreshDatabase;

    public function test_upsert_logic_counts_imported_updated_and_ignores_duplicates(): void
    {
        // Existing product that should be updated.
        Product::create([
            'sku' => 'SKU-1',
            'name' => 'Existing',
            'description' => 'Old',
            'price' => 10.00,
        ]);

        $csv = <<<CSV
sku,name,price,description
SKU-1,Updated Name,12.50,Updated description
SKU-2,New Product,5.00,Brand new
SKU-2,Duplicate Product,7.00,Duplicate row
CSV;

        $path = storage_path('framework/testing/products_import_test.csv');
        if (! is_dir(dirname($path))) {
            mkdir(dirname($path), 0775, true);
        }
        file_put_contents($path, $csv);

        $importer = new ProductCsvImporter();
        $summary = $importer->import($path);

        $this->assertSame(3, $summary['total']);
        $this->assertSame(1, $summary['imported']);
        $this->assertSame(1, $summary['updated']);
        $this->assertSame(0, $summary['invalid']);
        $this->assertSame(1, $summary['duplicates']);

        $this->assertDatabaseHas('products', [
            'sku' => 'SKU-1',
            'name' => 'Updated Name',
            'price' => 12.50,
        ]);

        $this->assertDatabaseHas('products', [
            'sku' => 'SKU-2',
            'name' => 'New Product',
            'price' => 5.00,
        ]);
    }
}




