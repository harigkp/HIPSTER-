<?php

namespace App\Http\Controllers;

use App\Services\ProductCsvImporter;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Support\Facades\Storage;

class ProductImportController extends Controller
{
    public function showForm(): View
    {
        return view('products.import');
    }

    public function handleImport(Request $request, ProductCsvImporter $importer): RedirectResponse
    {
        $validated = $request->validate([
            'csv' => ['required', 'file', 'mimes:csv,txt'],
        ]);

        /** @var \Illuminate\Http\UploadedFile $file */
        $file = $validated['csv'];

        $path = $file->storeAs('imports', 'products.csv', 'local');

        $fullPath = Storage::disk('local')->path($path);

        $summary = $importer->import($fullPath);

        return back()->with('summary', $summary);
    }
}




