<?php

namespace App\Http\Controllers;

use App\Models\Image;
use App\Models\Upload;
use App\Services\ImageVariantGenerator;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class UploadController extends Controller
{
    public function init(Request $request): JsonResponse
    {
        $data = $request->validate([
            'original_filename' => ['required', 'string'],
            'mime_type' => ['nullable', 'string'],
            'size' => ['nullable', 'integer', 'min:1'],
            'checksum' => ['required', 'string'],
            'total_chunks' => ['required', 'integer', 'min:1'],
        ]);

        $upload = Upload::create([
            'uuid' => (string) Str::uuid(),
            'original_filename' => $data['original_filename'],
            'mime_type' => $data['mime_type'] ?? null,
            'size' => $data['size'] ?? null,
            'checksum' => $data['checksum'],
            'total_chunks' => $data['total_chunks'],
            'status' => 'pending',
        ]);

        return response()->json([
            'uuid' => $upload->uuid,
        ]);
    }

    public function chunk(Request $request): JsonResponse
    {
        $data = $request->validate([
            'uuid' => ['required', 'string'],
            'index' => ['required', 'integer', 'min:0'],
            'total_chunks' => ['required', 'integer', 'min:1'],
            'chunk' => ['required', 'file'],
        ]);

        /** @var Upload|null $upload */
        $upload = Upload::where('uuid', $data['uuid'])->first();

        if (! $upload || $upload->status !== 'pending') {
            return response()->json(['message' => 'Upload not pending or not found.'], 422);
        }

        if ((int) $data['total_chunks'] !== (int) $upload->total_chunks) {
            return response()->json(['message' => 'Chunk count mismatch.'], 422);
        }

        if ((int) $data['index'] >= $upload->total_chunks) {
            return response()->json(['message' => 'Invalid chunk index.'], 422);
        }

        $chunk = $data['chunk'];

        $chunkPath = $this->chunkPath($upload->uuid, (int) $data['index']);

        // Overwrite existing chunk to keep re-sent chunks safe.
        Storage::disk('local')->put($chunkPath, $chunk->get());

        return response()->json([
            'status' => 'ok',
        ]);
    }

    public function complete(Request $request, ImageVariantGenerator $variantGenerator): JsonResponse
    {
        $data = $request->validate([
            'uuid' => ['required', 'string'],
        ]);

        /** @var Upload|null $upload */
        $upload = DB::transaction(function () use ($data) {
            return Upload::where('uuid', $data['uuid'])
                ->lockForUpdate()
                ->first();
        });

        if (! $upload) {
            return response()->json(['message' => 'Upload not found.'], 404);
        }

        if ($upload->status === 'completed' && $upload->storage_path && $upload->image) {
            return response()->json([
                'status' => 'completed',
                'upload_uuid' => $upload->uuid,
            ]);
        }

        if ($upload->status !== 'pending') {
            return response()->json(['message' => 'Upload not pending.'], 422);
        }

        $totalChunks = (int) $upload->total_chunks;

        // Ensure all chunks exist.
        for ($i = 0; $i < $totalChunks; $i++) {
            if (! Storage::disk('local')->exists($this->chunkPath($upload->uuid, $i))) {
                return response()->json(['message' => 'Missing chunks.'], 422);
            }
        }

        // Assemble final file.
        $originalRelative = 'uploads/originals/'.$upload->uuid.'_'.$upload->original_filename;
        $originalFull = Storage::disk('local')->path($originalRelative);

        if (! is_dir(dirname($originalFull))) {
            mkdir(dirname($originalFull), 0775, true);
        }

        $out = fopen($originalFull, 'wb');

        if ($out === false) {
            return response()->json(['message' => 'Unable to create assembled file.'], 500);
        }

        for ($i = 0; $i < $totalChunks; $i++) {
            $chunkFull = Storage::disk('local')->path($this->chunkPath($upload->uuid, $i));
            $in = fopen($chunkFull, 'rb');

            if ($in === false) {
                fclose($out);

                return response()->json(['message' => 'Unable to read chunk.'], 500);
            }

            while (! feof($in)) {
                $buffer = fread($in, 1024 * 1024);
                if ($buffer === false) {
                    break;
                }

                fwrite($out, $buffer);
            }

            fclose($in);
        }

        fclose($out);

        $checksum = hash_file('sha256', $originalFull);

        if ($upload->checksum && ! hash_equals($upload->checksum, $checksum)) {
            $upload->status = 'failed';
            $upload->save();

            return response()->json(['message' => 'Checksum mismatch.'], 422);
        }

        $upload->status = 'completed';
        $upload->storage_path = $originalRelative;
        $upload->size = filesize($originalFull) ?: $upload->size;
        $upload->save();

        $variantData = $variantGenerator->generate('local', $originalRelative);

        /** @var Image $image */
        $image = $upload->image ?: new Image(['upload_id' => $upload->id]);

        $image->upload_id = $upload->id;
        $image->original_path = $originalRelative;
        $image->variant_256_path = $variantData['variant_256_path'];
        $image->variant_512_path = $variantData['variant_512_path'];
        $image->variant_1024_path = $variantData['variant_1024_path'];
        $image->width = $variantData['width'];
        $image->height = $variantData['height'];
        $image->save();

        // Optionally, clean up chunk files.
        for ($i = 0; $i < $totalChunks; $i++) {
            Storage::disk('local')->delete($this->chunkPath($upload->uuid, $i));
        }

        return response()->json([
            'status' => 'completed',
            'upload_uuid' => $upload->uuid,
        ]);
    }

    protected function chunkPath(string $uuid, int $index): string
    {
        return "uploads/chunks/{$uuid}_{$index}.part";
    }
}




