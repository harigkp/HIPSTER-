<?php

namespace App\Services;

use App\Models\Image;
use App\Models\Product;
use App\Models\Upload;
use Illuminate\Support\Arr;

class ProductCsvImporter
{
    /**
     * Import a CSV file and upsert Products by SKU.
     *
     * @return array{
     *     total: int,
     *     imported: int,
     *     updated: int,
     *     invalid: int,
     *     duplicates: int
     * }
     */
    public function import(string $path): array
    {
        $handle = fopen($path, 'rb');

        if ($handle === false) {
            throw new \RuntimeException("Unable to open CSV at [{$path}]");
        }

        $header = fgetcsv($handle);

        if (! is_array($header)) {
            fclose($handle);

            return [
                'total' => 0,
                'imported' => 0,
                'updated' => 0,
                'invalid' => 0,
                'duplicates' => 0,
            ];
        }

        $header = array_map(static fn ($h) => strtolower(trim((string) $h)), $header);

        $required = ['sku', 'name'];
        $indices = [];
        foreach ($required as $column) {
            $index = array_search($column, $header, true);
            $indices[$column] = $index === false ? null : $index;
        }

        $hasRequired = ! in_array(null, $indices, true);

        $summary = [
            'total' => 0,
            'imported' => 0,
            'updated' => 0,
            'invalid' => 0,
            'duplicates' => 0,
        ];

        $seenSkus = [];

        while (($row = fgetcsv($handle)) !== false) {
            $summary['total']++;

            if (! $hasRequired) {
                $summary['invalid']++;
                continue;
            }

            $sku = trim((string) Arr::get($row, $indices['sku']));
            $name = trim((string) Arr::get($row, $indices['name']));

            if ($sku === '' || $name === '') {
                $summary['invalid']++;
                continue;
            }

            if (in_array($sku, $seenSkus, true)) {
                $summary['duplicates']++;
                continue;
            }

            $seenSkus[] = $sku;

            $product = Product::firstOrNew(['sku' => $sku]);

            $priceIndex = array_search('price', $header, true);
            $descriptionIndex = array_search('description', $header, true);
            $uploadUuidIndex = array_search('primary_upload_uuid', $header, true);

            $product->name = $name;

            if ($descriptionIndex !== false) {
                $product->description = trim((string) Arr::get($row, $descriptionIndex));
            }

            if ($priceIndex !== false) {
                $rawPrice = (string) Arr::get($row, $priceIndex);
                $product->price = is_numeric($rawPrice) ? (float) $rawPrice : 0;
            }

            $product->save();

            if ($product->wasRecentlyCreated) {
                $summary['imported']++;
            } else {
                $summary['updated']++;
            }

            if ($uploadUuidIndex !== false) {
                $uploadUuid = trim((string) Arr::get($row, $uploadUuidIndex));

                if ($uploadUuid !== '') {
                    $this->attachPrimaryImageFromUpload($product, $uploadUuid);
                }
            }
        }

        fclose($handle);

        return $summary;
    }

    protected function attachPrimaryImageFromUpload(Product $product, string $uploadUuid): void
    {
        /** @var Upload|null $upload */
        $upload = Upload::where('uuid', $uploadUuid)
            ->where('status', 'completed')
            ->first();

        if (! $upload) {
            return;
        }

        /** @var Image|null $image */
        $image = $upload->image;

        if (! $image) {
            return;
        }

        if ($product->primary_image_id === $image->id) {
            // Re-attaching same upload to same entity is a no-op.
            return;
        }

        $product->primary_image_id = $image->id;
        $product->save();
    }
}




