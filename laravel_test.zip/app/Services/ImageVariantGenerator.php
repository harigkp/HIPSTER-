<?php

namespace App\Services;

use Illuminate\Support\Facades\Storage;

class ImageVariantGenerator
{
    /**
     * Generate 256, 512 and 1024 px variants for the given image.
     *
     * @return array{
     *     width: int|null,
     *     height: int|null,
     *     variant_256_path: string|null,
     *     variant_512_path: string|null,
     *     variant_1024_path: string|null
     * }
     */
    public function generate(string $disk, string $path): array
    {
        $fullPath = Storage::disk($disk)->path($path);

        if (! is_file($fullPath)) {
            return [
                'width' => null,
                'height' => null,
                'variant_256_path' => null,
                'variant_512_path' => null,
                'variant_1024_path' => null,
            ];
        }

        [$width, $height, $type] = getimagesize($fullPath) ?: [null, null, null];

        if ($width === null || $height === null) {
            return [
                'width' => null,
                'height' => null,
                'variant_256_path' => null,
                'variant_512_path' => null,
                'variant_1024_path' => null,
            ];
        }

        $variantPaths = [
            256 => null,
            512 => null,
            1024 => null,
        ];

        foreach (array_keys($variantPaths) as $target) {
            $variantPaths[$target] = $this->resizeAndStore(
                $disk,
                $fullPath,
                $path,
                $width,
                $height,
                $type,
                $target,
            );
        }

        return [
            'width' => $width,
            'height' => $height,
            'variant_256_path' => $variantPaths[256],
            'variant_512_path' => $variantPaths[512],
            'variant_1024_path' => $variantPaths[1024],
        ];
    }

    protected function resizeAndStore(
        string $disk,
        string $sourceFullPath,
        string $originalRelativePath,
        int $width,
        int $height,
        int $type,
        int $targetSize,
    ): ?string {
        $scale = min($targetSize / $width, $targetSize / $height);

        if ($scale >= 1) {
            // Do not upscale, just reuse original.
            return $originalRelativePath;
        }

        $targetWidth = (int) floor($width * $scale);
        $targetHeight = (int) floor($height * $scale);

        $src = match ($type) {
            IMAGETYPE_JPEG => imagecreatefromjpeg($sourceFullPath),
            IMAGETYPE_PNG => imagecreatefrompng($sourceFullPath),
            default => null,
        };

        if (! $src) {
            return null;
        }

        $dst = imagecreatetruecolor($targetWidth, $targetHeight);
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $targetWidth, $targetHeight, $width, $height);

        $pathInfo = pathinfo($originalRelativePath);
        $variantRelative = sprintf(
            '%s/%s_%d.%s',
            $pathInfo['dirname'] !== '.' ? $pathInfo['dirname'] : 'uploads',
            $pathInfo['filename'],
            $targetSize,
            $pathInfo['extension'] ?? 'jpg',
        );

        $variantFullPath = Storage::disk($disk)->path($variantRelative);
        if (! is_dir(dirname($variantFullPath))) {
            mkdir(dirname($variantFullPath), 0775, true);
        }

        match ($type) {
            IMAGETYPE_JPEG => imagejpeg($dst, $variantFullPath, 90),
            IMAGETYPE_PNG => imagepng($dst, $variantFullPath),
            default => null,
        };

        imagedestroy($src);
        imagedestroy($dst);

        return $variantRelative;
    }
}




