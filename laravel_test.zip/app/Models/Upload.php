<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Upload extends Model
{
    use HasFactory;

    /**
     * @var list<string>
     */
    protected $fillable = [
        'uuid',
        'original_filename',
        'mime_type',
        'size',
        'checksum',
        'total_chunks',
        'status',
        'storage_path',
    ];

    public function image(): HasOne
    {
        return $this->hasOne(Image::class);
    }
}




