<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Image extends Model
{
    use HasFactory;

    /**
     * @var list<string>
     */
    protected $fillable = [
        'upload_id',
        'original_path',
        'variant_256_path',
        'variant_512_path',
        'variant_1024_path',
        'width',
        'height',
    ];

    public function upload(): BelongsTo
    {
        return $this->belongsTo(Upload::class);
    }
}




