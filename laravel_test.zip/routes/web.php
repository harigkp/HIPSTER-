<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/products/import', [\App\Http\Controllers\ProductImportController::class, 'showForm'])
    ->name('products.import.form');

Route::post('/products/import', [\App\Http\Controllers\ProductImportController::class, 'handleImport'])
    ->name('products.import.handle');

Route::post('/uploads/init', [\App\Http\Controllers\UploadController::class, 'init'])
    ->name('uploads.init');

Route::post('/uploads/chunk', [\App\Http\Controllers\UploadController::class, 'chunk'])
    ->name('uploads.chunk');

Route::post('/uploads/complete', [\App\Http\Controllers\UploadController::class, 'complete'])
    ->name('uploads.complete');

