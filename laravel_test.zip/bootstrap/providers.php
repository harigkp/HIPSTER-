<?php

return [
    App\Providers\AppServiceProvider::class,
    UserDiscounts\DiscountServiceProvider::class,
];
