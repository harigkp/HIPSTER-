<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product CSV Import & Image Upload</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <style>
        body { font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; margin: 2rem; background: #0f172a; color: #e5e7eb; }
        h1 { font-size: 1.75rem; margin-bottom: 1rem; }
        .card { background: #020617; border-radius: 0.75rem; padding: 1.5rem; border: 1px solid #1f2937; max-width: 960px; margin-bottom: 2rem; }
        .card h2 { font-size: 1.25rem; margin-bottom: 0.75rem; }
        .summary { margin-top: 1rem; font-size: 0.95rem; color: #a5b4fc; }
        .btn { display: inline-flex; align-items: center; justify-content: center; padding: 0.5rem 1rem; border-radius: 999px; border: none; background: linear-gradient(to right, #4f46e5, #06b6d4); color: white; font-weight: 600; cursor: pointer; font-size: 0.95rem; }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .dropzone { border-radius: 0.75rem; border: 2px dashed #374151; padding: 2rem; text-align: center; background: rgba(15,23,42,0.7); transition: border-color 0.15s ease, background-color 0.15s ease; cursor: pointer; }
        .dropzone.dragover { border-color: #38bdf8; background: rgba(15,23,42,0.9); }
        .muted { color: #9ca3af; font-size: 0.85rem; }
        .badge { display: inline-flex; align-items: center; padding: 0.15rem 0.5rem; border-radius: 999px; background: rgba(56,189,248,0.12); color: #7dd3fc; font-size: 0.75rem; margin-left: 0.5rem; }
        .progress { width: 100%; height: 8px; background: #020617; border-radius: 999px; overflow: hidden; margin-top: 0.75rem; }
        .progress-bar { height: 100%; width: 0; background: linear-gradient(to right, #4f46e5, #22c55e); transition: width 0.1s linear; }
        label { font-size: 0.9rem; display: block; margin-bottom: 0.25rem; color: #e5e7eb; }
        input[type="file"] { font-size: 0.85rem; color: #e5e7eb; }
        .row { display: flex; gap: 1.5rem; flex-wrap: wrap; }
        .col { flex: 1 1 280px; }
        .field { margin-bottom: 1rem; }
        code { background: #020617; padding: 0.1rem 0.35rem; border-radius: 0.25rem; }
    </style>
</head>
<body>
<h1>Bulk Product Import & Chunked Image Upload</h1>

<div class="card">
    <h2>CSV Import</h2>
    <p class="muted">
        Upload a CSV with columns <code>sku</code>, <code>name</code>, optional <code>price</code>, <code>description</code>, and <code>primary_upload_uuid</code>.
        Missing required columns or values mark the row as invalid but do not stop the import.
    </p>
    <form method="POST" action="{{ route('products.import.handle') }}" enctype="multipart/form-data">
        @csrf
        <div class="field">
            <label for="csv">CSV file (≥ 10,000 rows supported)</label>
            <input id="csv" type="file" name="csv" required>
        </div>
        <button class="btn" type="submit">Run Import</button>
    </form>

    @if (session('summary'))
        @php($s = session('summary'))
        <div class="summary">
            <div><strong>Total</strong>: {{ $s['total'] ?? 0 }}</div>
            <div><strong>Imported</strong>: {{ $s['imported'] ?? 0 }}</div>
            <div><strong>Updated</strong>: {{ $s['updated'] ?? 0 }}</div>
            <div><strong>Invalid</strong>: {{ $s['invalid'] ?? 0 }}</div>
            <div><strong>Duplicates</strong>: {{ $s['duplicates'] ?? 0 }}</div>
        </div>
    @endif
</div>

<div class="card">
    <div class="row">
        <div class="col">
            <h2>Chunked Image Upload <span class="badge">Resumable</span></h2>
            <p class="muted">
                Drag a large image here; it will be uploaded in 1&nbsp;MB chunks with checksum validation.
                Variants (256px, 512px, 1024px) are generated server-side while preserving aspect ratio.
            </p>
            <div id="dropzone" class="dropzone">
                <div id="dropzone-label">Drop image or click to select</div>
                <input id="file-input" type="file" accept="image/*" style="display:none">
                <div class="progress" style="margin-top:1rem;">
                    <div id="progress-bar" class="progress-bar"></div>
                </div>
                <div id="status" class="muted" style="margin-top:0.5rem;"></div>
                <div id="upload-uuid" class="muted" style="margin-top:0.5rem;"></div>
            </div>
        </div>
        <div class="col">
            <h2>Attach via CSV</h2>
            <p class="muted">
                Once an upload completes, copy its <code>upload_uuid</code> and place it in the
                <code>primary_upload_uuid</code> column of your CSV for the desired product row.
                Re-attaching the same upload to the same SKU is a no-op; primary image replacement is idempotent.
            </p>
        </div>
    </div>
</div>

<script>
    const csrf = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    function sha256(buffer) {
        return crypto.subtle.digest('SHA-256', buffer).then(hashBuffer => {
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        });
    }

    async function uploadFile(file) {
        const statusEl = document.getElementById('status');
        const progressEl = document.getElementById('progress-bar');
        const uuidEl = document.getElementById('upload-uuid');
        statusEl.textContent = 'Calculating checksum...';
        uuidEl.textContent = '';

        const buffer = await file.arrayBuffer();
        const checksum = await sha256(buffer);

        const chunkSize = 1024 * 1024;
        const totalChunks = Math.ceil(file.size / chunkSize);

        let initRes = await fetch('{{ route('uploads.init') }}', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': csrf
            },
            body: new URLSearchParams({
                original_filename: file.name,
                mime_type: file.type,
                size: file.size.toString(),
                checksum: checksum,
                total_chunks: totalChunks.toString()
            })
        });

        if (!initRes.ok) {
            statusEl.textContent = 'Failed to initialize upload.';
            return;
        }

        const initJson = await initRes.json();
        const uploadUuid = initJson.uuid;
        uuidEl.textContent = 'Upload UUID: ' + uploadUuid;

        statusEl.textContent = 'Uploading chunks...';

        for (let index = 0; index < totalChunks; index++) {
            const start = index * chunkSize;
            const end = Math.min(file.size, start + chunkSize);
            const chunkBlob = file.slice(start, end);

            const formData = new FormData();
            formData.append('uuid', uploadUuid);
            formData.append('index', index.toString());
            formData.append('total_chunks', totalChunks.toString());
            formData.append('chunk', chunkBlob, file.name + '.part' + index);

            const res = await fetch('{{ route('uploads.chunk') }}', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': csrf
                },
                body: formData
            });

            if (!res.ok) {
                statusEl.textContent = 'Chunk upload failed at index ' + index + '. You can retry; already-sent chunks are safe.';
                return;
            }

            progressEl.style.width = ((index + 1) / totalChunks * 100) + '%';
        }

        statusEl.textContent = 'Finalizing & generating variants...';

        const completeRes = await fetch('{{ route('uploads.complete') }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': csrf
            },
            body: JSON.stringify({ uuid: uploadUuid })
        });

        if (!completeRes.ok) {
            const msg = await completeRes.json().catch(() => ({}));
            statusEl.textContent = 'Upload failed: ' + (msg.message || 'Unknown error (checksum mismatch or missing chunks).');
            return;
        }

        const json = await completeRes.json();
        if (json.status === 'completed') {
            statusEl.textContent = 'Upload completed with variants. Use this UUID in your CSV: ' + uploadUuid;
        } else {
            statusEl.textContent = 'Upload did not complete.';
        }
    }

    (function () {
        const dropzone = document.getElementById('dropzone');
        const input = document.getElementById('file-input');

        dropzone.addEventListener('click', () => input.click());

        dropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropzone.classList.add('dragover');
        });
        dropzone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            dropzone.classList.remove('dragover');
        });
        dropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropzone.classList.remove('dragover');
            const file = e.dataTransfer.files[0];
            if (file) {
                uploadFile(file);
            }
        });

        input.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                uploadFile(file);
            }
        });
    })();
</script>
</body>
</html>




