<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('discount_audits', function (Blueprint $table): void {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('discount_id');
            $table->decimal('amount_before', 12, 2);
            $table->decimal('amount_after', 12, 2);
            $table->string('reference')->nullable();
            $table->timestamp('applied_at');
            $table->timestamps();

            $table->index(['user_id']);
            $table->index(['discount_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('discount_audits');
    }
};




