<?php

namespace UserDiscounts\Services;

use Carbon\CarbonImmutable;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use UserDiscounts\Events\DiscountApplied;
use UserDiscounts\Events\DiscountAssigned;
use UserDiscounts\Events\DiscountRevoked;
use UserDiscounts\Models\Discount;
use UserDiscounts\Models\DiscountAudit;
use UserDiscounts\Models\UserDiscount;

class DiscountManager
{
    /**
     * @param  array<string, mixed>  $config
     */
    public function __construct(
        protected array $config = [],
    ) {
    }

    public function assign(int $userId, int $discountId, ?int $maxUses = null): UserDiscount
    {
        $userDiscount = UserDiscount::firstOrNew([
            'user_id' => $userId,
            'discount_id' => $discountId,
        ]);

        $userDiscount->active = true;
        $userDiscount->revoked_at = null;

        if ($maxUses !== null) {
            $userDiscount->max_uses = $maxUses;
        }

        $userDiscount->save();

        DiscountAssigned::dispatch($userDiscount);

        return $userDiscount;
    }

    public function revoke(int $userId, int $discountId): void
    {
        $userDiscount = UserDiscount::where('user_id', $userId)
            ->where('discount_id', $discountId)
            ->first();

        if (! $userDiscount) {
            return;
        }

        $userDiscount->active = false;
        $userDiscount->revoked_at = now();
        $userDiscount->save();

        DiscountRevoked::dispatch($userDiscount);
    }

    /**
     * @return EloquentCollection<int, UserDiscount>
     */
    public function eligibleFor(int $userId, ?CarbonImmutable $at = null): EloquentCollection
    {
        $at = $at ?: CarbonImmutable::now();

        return UserDiscount::query()
            ->where('user_id', $userId)
            ->where('active', true)
            ->whereNull('revoked_at')
            ->whereHas('discount', function ($query) use ($at): void {
                $query->where('active', true)
                    ->where(function ($q) use ($at): void {
                        $q->whereNull('starts_at')
                            ->orWhere('starts_at', '<=', $at);
                    })
                    ->where(function ($q) use ($at): void {
                        $q->whereNull('ends_at')
                            ->orWhere('ends_at', '>=', $at);
                    });
            })
            ->where(function ($q): void {
                $q->whereNull('max_uses')
                    ->orWhereColumn('used', '<', 'max_uses');
            })
            ->with('discount')
            ->get();
    }

    /**
     * Apply all eligible discounts for a user to the given amount.
     *
     * This method is deterministic (stacking order is stable) and concurrency-safe
     * (usage is incremented within a DB transaction using row-level locks).
     *
     * @return array{
     *     original: float,
     *     final: float,
     *     applied_discounts: list<array{
     *         discount_id:int,
     *         amount_before:float,
     *         amount_after:float
     *     }>
     * }
     */
    public function apply(int $userId, float $amount, ?string $reference = null): array
    {
        $original = $amount;

        return DB::transaction(function () use ($userId, $amount, $original, $reference): array {
            $now = CarbonImmutable::now();

            /** @var EloquentCollection<int, UserDiscount> $eligible */
            $eligible = $this->eligibleFor($userId, $now);

            if ($eligible->isEmpty()) {
                return [
                    'original' => $original,
                    'final' => $this->roundAmount($amount),
                    'applied_discounts' => [],
                ];
            }

            // Lock all user_discount rows we might modify for concurrency safety.
            $ids = $eligible->pluck('id')->all();
            if (! empty($ids)) {
                UserDiscount::whereIn('id', $ids)->lockForUpdate()->get();
            }

            $stackingOrder = Arr::get($this->config, 'stacking_order', ['percentage', 'fixed']);

            $sorted = $eligible->sort(function (UserDiscount $a, UserDiscount $b) use ($stackingOrder): int {
                $aType = $a->discount->type;
                $bType = $b->discount->type;
                $aIndex = array_search($aType, $stackingOrder, true);
                $bIndex = array_search($bType, $stackingOrder, true);

                $aIndex = $aIndex === false ? PHP_INT_MAX : $aIndex;
                $bIndex = $bIndex === false ? PHP_INT_MAX : $bIndex;

                if ($aIndex === $bIndex) {
                    return $a->discount_id <=> $b->discount_id;
                }

                return $aIndex <=> $bIndex;
            });

            $applied = [];

            /** @var UserDiscount $userDiscount */
            foreach ($sorted as $userDiscount) {
                // Re-check usage caps under lock.
                $userDiscount->refresh();

                if ($userDiscount->max_uses !== null && $userDiscount->used >= $userDiscount->max_uses) {
                    continue;
                }

                /** @var Discount $discount */
                $discount = $userDiscount->discount;

                $before = $amount;
                $amount = $this->applySingleDiscount($original, $amount, $discount);

                // Increment usage and write audit.
                $userDiscount->increment('used');

                $audit = DiscountAudit::create([
                    'user_id' => $userId,
                    'discount_id' => $discount->id,
                    'amount_before' => $before,
                    'amount_after' => $amount,
                    'reference' => $reference,
                    'applied_at' => $now,
                ]);

                DiscountApplied::dispatch($audit);

                $applied[] = [
                    'discount_id' => $discount->id,
                    'amount_before' => $before,
                    'amount_after' => $amount,
                ];
            }

            $final = $this->roundAmount($amount);

            return [
                'original' => $original,
                'final' => $final,
                'applied_discounts' => $applied,
            ];
        });
    }

    protected function applySingleDiscount(float $original, float $current, Discount $discount): float
    {
        $type = $discount->type;
        $value = (float) $discount->value;

        if ($type === 'percentage') {
            $candidate = $current * (1 - $value / 100);
        } elseif ($type === 'fixed') {
            $candidate = max(0.0, $current - $value);
        } else {
            return $current;
        }

        $cap = (float) Arr::get($this->config, 'max_percentage_cap', 100.0);
        $minAllowed = $original * (1 - $cap / 100);

        return max($candidate, $minAllowed);
    }

    protected function roundAmount(float $amount): float
    {
        $strategy = Arr::get($this->config, 'rounding', 'half_up');

        return match ($strategy) {
            'half_up' => round($amount, 2, PHP_ROUND_HALF_UP),
            'half_down' => round($amount, 2, PHP_ROUND_HALF_DOWN),
            'floor' => floor($amount * 100) / 100,
            'ceil' => ceil($amount * 100) / 100,
            'none' => $amount,
            default => round($amount, 2, PHP_ROUND_HALF_UP),
        };
    }
}




