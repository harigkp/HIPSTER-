<?php

namespace UserDiscounts\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Discount extends Model
{
    use HasFactory;

    protected $table = 'discounts';

    /**
     * @var list<string>
     */
    protected $fillable = [
        'code',
        'name',
        'type',
        'value',
        'active',
        'starts_at',
        'ends_at',
    ];

    protected $casts = [
        'active' => 'bool',
        'starts_at' => 'datetime',
        'ends_at' => 'datetime',
        'value' => 'float',
    ];

    public function userDiscounts(): HasMany
    {
        return $this->hasMany(UserDiscount::class);
    }
}




