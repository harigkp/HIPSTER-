<?php

namespace UserDiscounts\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserDiscount extends Model
{
    use HasFactory;

    protected $table = 'user_discounts';

    /**
     * @var list<string>
     */
    protected $fillable = [
        'user_id',
        'discount_id',
        'max_uses',
        'used',
        'active',
        'revoked_at',
    ];

    protected $casts = [
        'active' => 'bool',
        'max_uses' => 'int',
        'used' => 'int',
        'revoked_at' => 'datetime',
    ];

    public function discount(): BelongsTo
    {
        return $this->belongsTo(Discount::class);
    }
}




