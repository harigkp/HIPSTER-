<?php

namespace UserDiscounts\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DiscountAudit extends Model
{
    use HasFactory;

    protected $table = 'discount_audits';

    /**
     * @var list<string>
     */
    protected $fillable = [
        'user_id',
        'discount_id',
        'amount_before',
        'amount_after',
        'reference',
        'applied_at',
    ];

    protected $casts = [
        'amount_before' => 'float',
        'amount_after' => 'float',
        'applied_at' => 'datetime',
    ];

    public function discount(): BelongsTo
    {
        return $this->belongsTo(Discount::class);
    }
}




