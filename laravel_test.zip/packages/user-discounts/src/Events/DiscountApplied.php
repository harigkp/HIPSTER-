<?php

namespace UserDiscounts\Events;

use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use UserDiscounts\Models\DiscountAudit;

class DiscountApplied
{
    use Dispatchable;
    use SerializesModels;

    public function __construct(
        public readonly DiscountAudit $audit
    ) {
    }
}




