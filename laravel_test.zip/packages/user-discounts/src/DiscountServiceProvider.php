<?php

namespace UserDiscounts;

use Illuminate\Support\ServiceProvider;
use UserDiscounts\Services\DiscountManager;

class DiscountServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../config/discounts.php', 'user_discounts');

        $this->app->singleton(DiscountManager::class, function ($app) {
            return new DiscountManager(
                config: $app['config']->get('user_discounts', []),
            );
        });
    }

    public function boot(): void
    {
        $this->publishes([
            __DIR__ . '/../config/discounts.php' => config_path('user_discounts.php'),
        ], 'config');

        $this->loadMigrationsFrom(__DIR__ . '/../database/migrations');
    }
}




