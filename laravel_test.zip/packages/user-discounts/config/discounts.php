<?php

return [
    /**
     * Default stacking order for discount types.
     *
     * Supported types: percentage, fixed.
     */
    'stacking_order' => [
        'percentage',
        'fixed',
    ],

    /**
     * Maximum overall percentage cap applied to the original amount.
     * Example: 50 means the final price will never be discounted by more than 50%.
     */
    'max_percentage_cap' => 50.0,

    /**
     * Rounding strategy applied to the final amount.
     *
     * Supported: half_up, half_down, floor, ceil, none
     */
    'rounding' => 'half_up',

    /**
     * User model class used for relations.
     */
    'user_model' => \App\Models\User::class,
];




