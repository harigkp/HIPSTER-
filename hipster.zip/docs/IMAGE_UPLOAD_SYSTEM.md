# Drag & Drop Image Upload System

This system provides a complete drag-and-drop image upload solution with chunked/resumable uploads and automatic image resizing.

## Features

- **Drag & Drop Interface**: Modern, intuitive drag-and-drop file upload area
- **Chunked Uploads**: Large files are split into 1MB chunks for reliable uploads
- **Resumable Uploads**: Failed uploads can be resumed from where they left off
- **Multiple Image Sizes**: Automatically generates thumbnail, small, medium, large, and original sizes
- **Progress Tracking**: Real-time upload progress with visual indicators
- **File Validation**: Validates file types and sizes before upload
- **Hash Verification**: SHA-256 hash verification for each chunk and final file
- **Cleanup System**: Automatic cleanup of expired and incomplete uploads
- **Responsive Design**: Works on desktop and mobile devices

## Components

### 1. Database Table (`image_uploads`)
- Stores upload session information
- Tracks chunk upload progress
- Stores file metadata and generated image sizes
- Includes expiration timestamps for cleanup

### 2. Model (`ImageUpload`)
- Handles image size generation using Intervention Image
- Provides methods for upload status checking
- Manages file cleanup operations
- Includes scopes for expired and incomplete uploads

### 3. Controller (`ImageUploadController`)
- Handles upload initialization
- Processes chunked uploads
- Manages upload completion and file combination
- Provides status checking and cancellation
- Handles image deletion

### 4. Frontend (`image-upload.js`)
- JavaScript class for handling drag-and-drop
- Manages chunked upload process
- Provides real-time progress updates
- Handles file validation and error management

### 5. View (`image-upload.blade.php`)
- Modern, responsive upload interface
- Progress tracking display
- Image gallery with preview modal
- Size selection for image preview

## Installation

1. **Run Migration**:
   ```bash
   php artisan migrate
   ```

2. **Install Dependencies**:
   ```bash
   composer install
   ```

3. **Create Storage Directories**:
   ```bash
   mkdir -p storage/app/public/uploads/images
   mkdir -p storage/app/temp/chunks
   ```

4. **Set Up Storage Link** (if not already done):
   ```bash
   php artisan storage:link
   ```

## Usage

### Access the Upload Interface
Navigate to `/admin/image-upload` to access the upload interface.

### Upload Process
1. Drag and drop images onto the upload area or click to browse
2. Files are automatically validated and chunked
3. Upload progress is displayed in real-time
4. Multiple image sizes are generated automatically
5. Uploaded images appear in the gallery below

### API Endpoints

- `POST /admin/image-upload/initialize` - Initialize new upload session
- `POST /admin/image-upload/upload-chunk` - Upload a file chunk
- `GET /admin/image-upload/status` - Get upload status
- `POST /admin/image-upload/cancel` - Cancel an upload
- `GET /admin/image-upload/images` - Get uploaded images
- `POST /admin/image-upload/delete` - Delete an image

## Configuration

### Chunk Size
Default chunk size is 1MB. To modify, update the `chunkSize` property in `image-upload.js`:

```javascript
this.chunkSize = 1024 * 1024; // 1MB chunks
```

### Image Sizes
Image sizes are configured in the `ImageUpload` model's `generateImageSizes` method:

```php
$sizes = [
    'thumbnail' => [150, 150],
    'small' => [300, 300],
    'medium' => [600, 600],
    'large' => [1200, 1200],
    'original' => null
];
```

### File Limits
- Maximum file size: 100MB per file
- Maximum chunks: 1000 per file
- Supported formats: JPG, PNG, GIF, WebP

## Maintenance

### Cleanup Expired Uploads
Run the cleanup command manually:
```bash
php artisan uploads:cleanup
```

Or let it run automatically via the scheduler (configured to run hourly).

### Monitor Upload Status
Check the `image_uploads` table for upload status and progress:
```sql
SELECT upload_id, original_filename, upload_status, uploaded_chunks, total_chunks 
FROM image_uploads 
WHERE upload_status != 'completed';
```

## Security Features

- CSRF protection on all endpoints
- File type validation
- File size limits
- Hash verification for chunks
- Automatic cleanup of incomplete uploads
- Secure file storage paths

## Error Handling

The system includes comprehensive error handling:
- Network failure recovery
- Chunk verification failures
- File system errors
- Database transaction rollbacks
- User-friendly error messages

## Browser Support

- Chrome 60+
- Firefox 55+
- Safari 11+
- Edge 79+

## Dependencies

- Laravel 11+
- Intervention Image 3.0+
- Bootstrap 5+ (for UI components)
- Modern JavaScript (ES6+)

## Troubleshooting

### Common Issues

1. **Upload fails immediately**: Check file size limits and supported formats
2. **Chunks fail to upload**: Verify network stability and server timeout settings
3. **Images not generating**: Ensure Intervention Image is properly installed and GD/Imagick is available
4. **Storage issues**: Check directory permissions and available disk space

### Debug Mode
Enable Laravel debug mode to see detailed error messages:
```env
APP_DEBUG=true
```

### Logs
Check Laravel logs for detailed error information:
```bash
tail -f storage/logs/laravel.log
```

